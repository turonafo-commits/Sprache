package com.turonafo.sprachen;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String PREFS = "sprachen_offline_progress";
    private static final String[] UI_LANGS = {"Deutsch", "Русский"};
    private static final String[] LEARN_LANGS = {"Englisch", "Spanisch"};
    private static final String[] LEVELS = {"A0", "A1", "A2", "B1", "B2"};

    private final Map<String, List<Card>> cards = new LinkedHashMap<>();
    private SharedPreferences prefs;
    private LinearLayout root;
    private Spinner userSpinner;
    private Spinner uiSpinner;
    private Spinner learnSpinner;
    private Spinner levelSpinner;
    private TextView promptView;
    private TextView progressView;
    private RadioGroup choicesGroup;
    private Button answerButton;
    private Button nextButton;
    private EditText newUserEdit;

    private String currentUser = "Gast";
    private int currentCardIndex = 0;
    private Card currentCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        seedCards();
        ensureDefaultUsers();
        buildLayout();
        loadState();
        refreshExercise();
    }

    private void buildLayout() {
        ScrollView scrollView = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        root.setBackgroundColor(Color.rgb(248, 250, 252));
        scrollView.addView(root);

        TextView title = text("Sprachen", 30, true);
        title.setTextColor(Color.rgb(15, 118, 110));
        root.addView(title);
        root.addView(text("Offline Sprachtraining mit lokalen Profilen", 15, false));

        userSpinner = spinner();
        uiSpinner = spinnerWith(UI_LANGS);
        learnSpinner = spinnerWith(LEARN_LANGS);
        levelSpinner = spinnerWith(LEVELS);

        root.addView(label("Benutzer"));
        root.addView(userSpinner);

        LinearLayout addUserRow = new LinearLayout(this);
        addUserRow.setOrientation(LinearLayout.HORIZONTAL);
        addUserRow.setGravity(Gravity.CENTER_VERTICAL);
        newUserEdit = new EditText(this);
        newUserEdit.setHint("Neuer Name");
        newUserEdit.setSingleLine(true);
        addUserRow.addView(newUserEdit, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button addUserButton = button("+");
        addUserRow.addView(addUserButton, new LinearLayout.LayoutParams(dp(56), dp(48)));
        root.addView(addUserRow);

        root.addView(label("UI-Sprache"));
        root.addView(uiSpinner);
        root.addView(label("Lernsprache"));
        root.addView(learnSpinner);
        root.addView(label("Level"));
        root.addView(levelSpinner);

        progressView = text("", 16, true);
        progressView.setPadding(0, dp(16), 0, dp(8));
        root.addView(progressView);

        promptView = text("", 22, true);
        promptView.setTextColor(Color.rgb(17, 24, 39));
        promptView.setPadding(0, dp(18), 0, dp(12));
        root.addView(promptView);

        choicesGroup = new RadioGroup(this);
        choicesGroup.setOrientation(RadioGroup.VERTICAL);
        root.addView(choicesGroup);

        answerButton = button("Antwort prüfen");
        nextButton = button("Weiter");
        root.addView(answerButton);
        root.addView(nextButton);

        addUserButton.setOnClickListener(v -> addUser());
        answerButton.setOnClickListener(v -> checkAnswer());
        nextButton.setOnClickListener(v -> nextCard());

        AdapterView.OnItemSelectedListener settingsListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                saveState();
                currentCardIndex = getSavedIndex();
                refreshExercise();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        };

        userSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentUser = userSpinner.getSelectedItem().toString();
                saveState();
                currentCardIndex = getSavedIndex();
                refreshExercise();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        uiSpinner.setOnItemSelectedListener(settingsListener);
        learnSpinner.setOnItemSelectedListener(settingsListener);
        levelSpinner.setOnItemSelectedListener(settingsListener);

        setContentView(scrollView);
    }

    private void loadState() {
        updateUsers();
        selectSpinnerValue(userSpinner, prefs.getString("current_user", "Gast"));
        selectSpinnerValue(uiSpinner, prefs.getString("ui_lang", "Deutsch"));
        selectSpinnerValue(learnSpinner, prefs.getString("learn_lang", "Englisch"));
        selectSpinnerValue(levelSpinner, prefs.getString("level", "A0"));
        currentUser = userSpinner.getSelectedItem().toString();
        currentCardIndex = getSavedIndex();
    }

    private void saveState() {
        if (userSpinner == null || uiSpinner == null || learnSpinner == null || levelSpinner == null) {
            return;
        }
        prefs.edit()
                .putString("current_user", userSpinner.getSelectedItem().toString())
                .putString("ui_lang", uiSpinner.getSelectedItem().toString())
                .putString("learn_lang", learnSpinner.getSelectedItem().toString())
                .putString("level", levelSpinner.getSelectedItem().toString())
                .apply();
    }

    private void refreshExercise() {
        if (promptView == null || choicesGroup == null || userSpinner.getSelectedItem() == null) {
            return;
        }
        currentUser = userSpinner.getSelectedItem().toString();
        List<Card> deck = currentDeck();
        if (deck.isEmpty()) {
            promptView.setText(t("Keine Übung vorhanden", "Нет упражнения"));
            return;
        }
        currentCardIndex = Math.floorMod(currentCardIndex, deck.size());
        currentCard = deck.get(currentCardIndex);

        promptView.setText(t("Was bedeutet: ", "Что означает: ") + currentCard.source);
        choicesGroup.removeAllViews();
        for (String option : currentCard.options) {
            RadioButton button = new RadioButton(this);
            button.setText(option);
            button.setTextSize(18);
            button.setPadding(0, dp(8), 0, dp(8));
            choicesGroup.addView(button);
        }
        updateProgressText();
        answerButton.setText(t("Antwort prüfen", "Проверить ответ"));
        nextButton.setText(t("Weiter", "Дальше"));
    }

    private void checkAnswer() {
        int checkedId = choicesGroup.getCheckedRadioButtonId();
        if (checkedId == -1) {
            Toast.makeText(this, t("Bitte eine Antwort wählen.", "Выберите ответ."), Toast.LENGTH_SHORT).show();
            return;
        }
        RadioButton selected = findViewById(checkedId);
        boolean correct = selected.getText().toString().equals(currentCard.answer);
        String base = progressKey();
        int attempts = prefs.getInt(base + "_attempts", 0) + 1;
        int correctCount = prefs.getInt(base + "_correct", 0) + (correct ? 1 : 0);
        prefs.edit()
                .putInt(base + "_attempts", attempts)
                .putInt(base + "_correct", correctCount)
                .apply();
        Toast.makeText(this, correct
                ? t("Richtig!", "Верно!")
                : t("Noch nicht. Richtig ist: ", "Пока нет. Правильно: ") + currentCard.answer,
                Toast.LENGTH_LONG).show();
        updateProgressText();
    }

    private void nextCard() {
        List<Card> deck = currentDeck();
        currentCardIndex = (currentCardIndex + 1) % deck.size();
        prefs.edit().putInt(progressKey() + "_index", currentCardIndex).apply();
        refreshExercise();
    }

    private void addUser() {
        String name = newUserEdit.getText().toString().trim();
        if (name.isEmpty()) {
            return;
        }
        List<String> users = loadUsers();
        if (!users.contains(name)) {
            users.add(name);
            saveUsers(users);
        }
        newUserEdit.setText("");
        updateUsers();
        selectSpinnerValue(userSpinner, name);
    }

    private void updateProgressText() {
        String base = progressKey();
        int attempts = prefs.getInt(base + "_attempts", 0);
        int correctCount = prefs.getInt(base + "_correct", 0);
        int percent = attempts == 0 ? 0 : Math.round((correctCount * 100f) / attempts);
        String learn = learnSpinner.getSelectedItem().toString();
        String level = levelSpinner.getSelectedItem().toString();
        progressView.setText(t(
                String.format(Locale.GERMANY, "%s - %s - Fortschritt: %d/%d richtig (%d%%)", learn, level, correctCount, attempts, percent),
                String.format(Locale.US, "%s - %s - прогресс: %d/%d верно (%d%%)", learn, level, correctCount, attempts, percent)
        ));
    }

    private List<Card> currentDeck() {
        String key = learnSpinner.getSelectedItem().toString() + "_" + levelSpinner.getSelectedItem().toString();
        return cards.get(key);
    }

    private String progressKey() {
        return currentUser + "_" + learnSpinner.getSelectedItem() + "_" + levelSpinner.getSelectedItem();
    }

    private int getSavedIndex() {
        return prefs.getInt(progressKey() + "_index", 0);
    }

    private String t(String de, String ru) {
        return "Русский".equals(uiSpinner.getSelectedItem().toString()) ? ru : de;
    }

    private void ensureDefaultUsers() {
        if (!prefs.contains("users")) {
            saveUsers(new ArrayList<>(Arrays.asList("Gast")));
        }
    }

    private List<String> loadUsers() {
        ArrayList<String> users = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs.getString("users", "[\"Gast\"]"));
            for (int i = 0; i < array.length(); i++) {
                users.add(array.getString(i));
            }
        } catch (JSONException e) {
            users.add("Gast");
        }
        return users;
    }

    private void saveUsers(List<String> users) {
        JSONArray array = new JSONArray();
        for (String user : users) {
            array.put(user);
        }
        prefs.edit().putString("users", array.toString()).apply();
    }

    private void updateUsers() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, loadUsers());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userSpinner.setAdapter(adapter);
    }

    private Spinner spinner() {
        Spinner spinner = new Spinner(this);
        spinner.setPadding(0, dp(6), 0, dp(6));
        return spinner;
    }

    private Spinner spinnerWith(String[] values) {
        Spinner spinner = spinner();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        return spinner;
    }

    private TextView label(String value) {
        TextView label = text(value, 13, true);
        label.setTextColor(Color.rgb(71, 85, 105));
        label.setPadding(0, dp(16), 0, dp(4));
        return label;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(Color.rgb(51, 65, 85));
        if (bold) {
            view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        }
        return view;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setAllCaps(false);
        return button;
    }

    private void selectSpinnerValue(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getAdapter().getCount(); i++) {
            if (spinner.getAdapter().getItem(i).equals(value)) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void seedCards() {
        put("Englisch_A0", "hello", "Hallo", "Danke", "Bitte", "Tisch");
        put("Englisch_A0", "water", "Wasser", "Brot", "Fenster", "Haus");
        put("Englisch_A1", "I am learning.", "Ich lerne.", "Ich schlafe.", "Ich warte.", "Ich laufe.");
        put("Englisch_A1", "Where is the station?", "Wo ist der Bahnhof?", "Wie spät ist es?", "Was kostet das?", "Wer bist du?");
        put("Englisch_A2", "appointment", "Termin", "Rechnung", "Koffer", "Nachricht");
        put("Englisch_A2", "She has already eaten.", "Sie hat schon gegessen.", "Sie wird essen.", "Sie isst gerade.", "Sie kocht nicht.");
        put("Englisch_B1", "although", "obwohl", "deshalb", "trotzdem", "während");
        put("Englisch_B1", "The meeting was postponed.", "Das Treffen wurde verschoben.", "Das Treffen fiel aus.", "Das Treffen begann früher.", "Das Treffen war laut.");
        put("Englisch_B2", "sustainable", "nachhaltig", "oberflächlich", "zuverlässig", "vorläufig");
        put("Englisch_B2", "He raised a valid objection.", "Er erhob einen berechtigten Einwand.", "Er stellte eine falsche Frage.", "Er schrieb einen kurzen Bericht.", "Er gewann eine knappe Wahl.");

        put("Spanisch_A0", "hola", "Hallo", "Danke", "Brot", "Straße");
        put("Spanisch_A0", "agua", "Wasser", "Milch", "Stuhl", "Schule");
        put("Spanisch_A1", "Estoy aprendiendo.", "Ich lerne.", "Ich kaufe ein.", "Ich arbeite.", "Ich reise.");
        put("Spanisch_A1", "¿Dónde está la estación?", "Wo ist der Bahnhof?", "Wann beginnt es?", "Was kostet das?", "Wie heißt du?");
        put("Spanisch_A2", "cita", "Termin", "Rechnung", "Miete", "Nachbar");
        put("Spanisch_A2", "Ella ya ha comido.", "Sie hat schon gegessen.", "Sie möchte essen.", "Sie isst später.", "Sie kocht Reis.");
        put("Spanisch_B1", "aunque", "obwohl", "deshalb", "bevor", "danach");
        put("Spanisch_B1", "La reunión fue aplazada.", "Das Treffen wurde verschoben.", "Das Treffen war kurz.", "Das Treffen begann pünktlich.", "Das Treffen wurde bestätigt.");
        put("Spanisch_B2", "sostenible", "nachhaltig", "vorläufig", "ehrgeizig", "deutlich");
        put("Spanisch_B2", "Planteó una objeción válida.", "Er erhob einen berechtigten Einwand.", "Er machte einen Vorschlag.", "Er löste das Problem.", "Er beschrieb die Lage.");
    }

    private void put(String key, String source, String answer, String wrong1, String wrong2, String wrong3) {
        if (!cards.containsKey(key)) {
            cards.put(key, new ArrayList<>());
        }
        cards.get(key).add(new Card(source, answer, Arrays.asList(answer, wrong1, wrong2, wrong3)));
    }

    private static class Card {
        final String source;
        final String answer;
        final List<String> options;

        Card(String source, String answer, List<String> options) {
            this.source = source;
            this.answer = answer;
            this.options = options;
        }
    }
}

